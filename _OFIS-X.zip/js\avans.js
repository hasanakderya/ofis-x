﻿(function() {
    var KEY = "avansList";
    function getAll() { return window.StorageHelper.load(KEY, []); }
    function ekle(kod, ad, miktar, aciklama) {
        var list = getAll();
        list.push({ id: Date.now(), tarih: new Date().toLocaleDateString("tr-TR"), personelKod: kod, personelAd: ad, miktar: miktar, aciklama: aciklama, odendi: false });
        window.StorageHelper.save(KEY, list);
    }
    function odendi(id) {
        var list = getAll();
        var a = list.find(function(x) { return x.id === id; });
        if (a) { a.odendi = true; window.StorageHelper.save(KEY, list); }
    }
    function sil(id) {
        var list = getAll().filter(function(x) { return x.id !== id; });
        window.StorageHelper.save(KEY, list);
    }
    function getBekleyen(kod) {
        return getAll().filter(function(a) { return a.personelKod === kod && !a.odendi; });
    }
    window.AvansModule = { getAll: getAll, ekle: ekle, odendi: odendi, sil: sil, getBekleyen: getBekleyen };
})();
