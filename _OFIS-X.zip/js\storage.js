﻿window.StorageHelper = (function() {
    function save(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            if (window.Senkron && window.Senkron.isOnline()) window.Senkron.yaz(key, value);
            return true;
        } catch(e) { console.error(e); return false; }
    }
    function load(key, defaultValue) {
        try {
            var raw = localStorage.getItem(key);
            if (!raw) return defaultValue;
            return JSON.parse(raw);
        } catch(e) { return defaultValue; }
    }
    return { save: save, load: load };
})();
