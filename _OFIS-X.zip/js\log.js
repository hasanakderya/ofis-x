﻿(function() {
    var KEY = "logList";
    function getAll() { return window.StorageHelper.load(KEY, []); }
    function ekle(kod, tip) {
        var p = window.findPersonelByKod(kod);
        if (!p) return;
        var now = new Date();
        var entry = {
            id: Date.now(), tarih: now.toLocaleDateString("tr-TR"),
            saat: now.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }),
            personelKod: kod, personelAd: p.adSoyad, tip: tip
        };
        var list = getAll();
        list.push(entry);
        window.StorageHelper.save(KEY, list);
        renderLogTable();
    }
    function renderLogTable() {
        var tbody = document.querySelector("#logTable tbody");
        if (!tbody) return;
        var list = getAll();
        list.sort(function(a,b) { return b.id - a.id; });
        tbody.innerHTML = "";
        if (!list.length) { tbody.innerHTML = "<tr><td colspan='5'>Henuz kayit yok</td></tr>"; return; }
        list.slice(0,50).forEach(function(e) {
            var tr = document.createElement("tr");
            tr.innerHTML = "<td>" + e.tarih + "</td><td>" + e.personelAd + "</td>" +
                "<td style='color:#198754;'>" + (e.tip === "Giris" ? e.saat : "-") + "</td>" +
                "<td style='color:#dc3545;'>" + (e.tip === "Cikis" ? e.saat : "-") + "</td>" +
                "<td>-</td>";
            tbody.appendChild(tr);
        });
    }
    function filterByDate(tarih) {
        if (!tarih) return renderLogTable();
        var list = getAll().filter(function(e) { return e.tarih === tarih; });
        var tbody = document.querySelector("#logTable tbody");
        if (!tbody) return;
        tbody.innerHTML = "";
        list.forEach(function(e) {
            var tr = document.createElement("tr");
            tr.innerHTML = "<td>" + e.tarih + "</td><td>" + e.personelAd + "</td><td>" + e.saat + "</td><td>" + e.tip + "</td><td>-</td>";
            tbody.appendChild(tr);
        });
    }
    window.LogModule = { ekle: ekle, getAll: getAll };
    window.addLogEntry = ekle;
    window.filterLogByDate = filterByDate;
    window.logTabAcildi = renderLogTable;
    window.addEventListener("load", renderLogTable);
})();
