// senkron.js - Firebase REST API ile Senkronizasyon
// Bu modül Firebase Realtime Database REST API kullanir

(function() {
    var config = null;
    var baseUrl = null;
    var isOnline = false;

    function init() {
        if (!window.firebaseConfig || !window.firebaseConfig.databaseURL) {
            console.log("Firebase config yok!");
            return false;
        }
        
        config = window.firebaseConfig;
        baseUrl = config.databaseURL + "/";
        isOnline = true;
        console.log("Firebase hazir!");
        return true;
    }

    // Firebase'e yaz (REST API)
    function yaz(key, data, callback) {
        // localStorage yedek
        localStorage.setItem(key, JSON.stringify(data));
        
        if (!isOnline || !baseUrl) {
            if (callback) callback(false);
            return;
        }

        var url = baseUrl + window.FIREBASE_KEY + "/" + key + ".json?auth=" + config.apiKey;
        
        // apiKey aslinda API key degil, ama Firebase REST calismiyor
        // Bunun yerine anonım erisim kullanalim
        url = baseUrl + window.FIREBASE_KEY + "/" + key + ".json";
        
        fetch(url, {
            method: "PUT",
            body: JSON.stringify(data),
            headers: { "Content-Type": "application/json" }
        })
        .then(function(res) {
            if (res.ok) {
                console.log("Firebase yazildi: " + key);
                if (callback) callback(true);
            } else {
                console.log("Firebase yazim hatasi");
                if (callback) callback(false);
            }
        })
        .catch(function(e) {
            console.log("Network hatasi: " + e.message);
            if (callback) callback(false);
        });
    }

    // Firebase'den oku
    function oku(key, callback) {
        if (!isOnline || !baseUrl) {
            var data = localStorage.getItem(key);
            callback(data ? JSON.parse(data) : null);
            return;
        }

        var url = baseUrl + window.FIREBASE_KEY + "/" + key + ".json";
        
        fetch(url)
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data) {
                localStorage.setItem(key, JSON.stringify(data));
                callback(data);
            } else {
                var local = localStorage.getItem(key);
                callback(local ? JSON.parse(local) : null);
            }
        })
        .catch(function() {
            var local = localStorage.getItem(key);
            callback(local ? JSON.parse(local) : null);
        });
    }

    // Otomatik senkron
    var syncKeys = ["personelList", "logList", "avansList", "maasOdemeList"];
    
    function autoSync() {
        if (!isOnline) return;
        syncKeys.forEach(function(key) {
            oku(key, function(data) {
                if (data && window.StorageHelper) {
                    window.StorageHelper.save(key, data);
                }
            });
        });
    }

    window.Senkron = {
        init: init,
        oku: oku,
        yaz: yaz,
        autoSync: autoSync,
        isOnline: function() { return isOnline; }
    };

    document.addEventListener("DOMContentLoaded", function() {
        init();
        setInterval(autoSync, 10000);
    });
})();
