﻿(function() {
    var currentModeLabel = document.getElementById("currentModeLabel");
    var btnSwitchMode = document.getElementById("btnSwitchMode");
    var personelScreen = document.getElementById("personelScreen");
    var adminScreen = document.getElementById("adminScreen");
    var clockEl = document.getElementById("clock");
    var statusText = document.getElementById("statusText");
    var tabButtons = document.querySelectorAll(".tab-btn");
    var tabs = document.querySelectorAll(".tab");
    var btnStartQr = document.getElementById("btnStartQr");
    var personelKodInput = document.getElementById("personelKodInput");
    var btnGiris = document.getElementById("btnGiris");
    var btnCikis = document.getElementById("btnCikis");
    var lastAction = document.getElementById("lastAction");

    function updateClock() {
        if (clockEl) clockEl.textContent = new Date().toLocaleString("tr-TR");
    }
    setInterval(updateClock, 1000);
    updateClock();

    function applyMode(m) {
        if (m === "personel") {
            personelScreen.classList.remove("hidden");
            adminScreen.classList.add("hidden");
            currentModeLabel.textContent = "Mod: Personel";
            btnSwitchMode.textContent = "Yonetici Girisi";
        } else {
            personelScreen.classList.add("hidden");
            adminScreen.classList.remove("hidden");
            currentModeLabel.textContent = "Mod: Yonetici";
            btnSwitchMode.textContent = "Personel Ekrani";
            if (window.refreshPersonelSelectleri) window.refreshPersonelSelectleri();
        }
    }

    if (btnSwitchMode) {
        btnSwitchMode.addEventListener("click", function() {
            if (adminScreen.classList.contains("hidden")) {
                if (window.Auth) {
                    window.Auth.sifreIste(function() { applyMode("admin"); setStatus("Yonetici paneline giris yapildi."); });
                } else { applyMode("admin"); }
            } else {
                applyMode("personel");
                setStatus("Personel moduna donuldu.");
            }
        });
    }

    tabButtons.forEach(function(btn) {
        btn.addEventListener("click", function() {
            var target = btn.getAttribute("data-tab");
            tabButtons.forEach(function(b) { b.classList.remove("active"); });
            tabs.forEach(function(t) { t.classList.remove("active"); });
            btn.classList.add("active");
            var tabEl = document.getElementById(target);
            if (tabEl) tabEl.classList.add("active");
            if (target === "maasTab" && window.maasTabAcildi) window.maasTabAcildi();
            if (target === "avansTab" && window.renderAvansTable) window.renderAvansTable();
            if (target === "raporTab" && window.raporTabAcildi) window.raporTabAcildi();
        });
    });

    function setStatus(msg) { if (statusText) statusText.textContent = msg; }

    window.personelIslemYap = function(kod, zorluTip) {
        kod = (kod || "").trim().toUpperCase();
        if (!kod) { alert("Lutfen personel kodu girin."); return; }
        var p = window.findPersonelByKod ? window.findPersonelByKod(kod) : null;
        if (!p) { alert("YANLIS KOD: " + kod); return; }
        if (!p.aktif) { alert(p.adSoyad + " pasif durumdadir."); return; }

        var tip;
        if (zorluTip) tip = zorluTip;
        else {
            var logList = window.StorageHelper ? window.StorageHelper.load("logList", []) : [];
            var sonHareket = logList.slice().reverse().find(function(l) { return l.personelKod === kod; });
            tip = (!sonHareket || sonHareket.tip === "Cikis") ? "Giris" : "Cikis";
        }
        var time = new Date().toLocaleTimeString("tr-TR");
        var isaret = tip === "Giris" ? "[GIRIS]" : "[CIKIS]";

        if (lastAction) {
            lastAction.innerHTML = "<strong>" + isaret + "</strong> - " + p.adSoyad + " (" + kod + ") - " + time;
            lastAction.style.color = tip === "Giris" ? "#198754" : "#dc3545";
        }
        if (window.addLogEntry) window.addLogEntry(kod, tip);
        setStatus(p.adSoyad + " - " + tip + " kaydedildi.");
        if (personelKodInput) { personelKodInput.value = ""; personelKodInput.focus(); }
    };

    if (btnGiris) {
        btnGiris.addEventListener("click", function() {
            window.personelIslemYap(personelKodInput ? personelKodInput.value : "", "Giris");
        });
    }
    if (btnCikis) {
        btnCikis.addEventListener("click", function() {
            window.personelIslemYap(personelKodInput ? personelKodInput.value : "", "Cikis");
        });
    }
    if (personelKodInput) {
        personelKodInput.addEventListener("keydown", function(e) {
            if (e.key === "Enter") window.personelIslemYap(personelKodInput.value);
        });
    }

    if (btnStartQr) {
        btnStartQr.addEventListener("click", function() {
            if (window.startQrScanner) window.startQrScanner();
        });
    }

    var btnSifreDegistir = document.getElementById("btnSifreDegistir");
    if (btnSifreDegistir) {
        btnSifreDegistir.addEventListener("click", function() {
            if (window.Auth) window.Auth.sifreDegistir();
        });
    }

    window.addEventListener("load", function() {
        applyMode("personel");
        if (personelKodInput) personelKodInput.focus();
        setStatus("Sistem hazir.");
    });
})();
