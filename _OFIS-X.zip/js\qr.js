﻿(function() {
    var video, canvas, stream;
    function start() {
        video = document.getElementById("qrVideo");
        if (!video) return;
        navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } }).then(function(s) {
            stream = s; video.srcObject = s;
        }).catch(function(e) { alert("Kamera bulunamadi: " + e.message); });
    }
    function dur() {
        if (stream) stream.getTracks().forEach(function(t) { t.stop(); });
    }
    window.startQrScanner = start;
})();
