﻿(function() {
    var KEY = "aylikKapanList";
    function getAll() { return window.StorageHelper.load(KEY, []); }
    function kapan(id) {
        var list = getAll();
        list.push({ id: id, tarih: new Date().toLocaleDateString("tr-TR"), saat: new Date().toLocaleTimeString("tr-TR") });
        window.StorageHelper.save(KEY, list);
    }
    window.AylikKapanModule = { getAll: getAll, kapan: kapan };
})();
