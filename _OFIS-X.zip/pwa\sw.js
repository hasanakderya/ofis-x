﻿const CACHE_NAME = "ofis-takip-v1";
const OFFLINE_URL = "/pwa/offline.html";

const ASSETS_TO_CACHE = [
  "/",
  "/index.html",
  "/css/style.css",
  "/css/responsive.css",
  "/js/app.js",
  "/js/storage.js",
  "/js/qr.js",
  "/js/personel.js",
  "/js/log.js",
  "/js/maas.js",
  "/pwa/manifest.json",
  OFFLINE_URL
];

// Kurulum
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS_TO_CACHE))
  );
  self.skipWaiting();
});

// Aktivasyon
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      )
    )
  );
  self.clients.claim();
});

// İstekler
self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        return response;
      })
      .catch(() => {
        return caches.match(event.request).then((cached) => {
          if (cached) return cached;
          return caches.match(OFFLINE_URL);
        });
      })
  );
});
