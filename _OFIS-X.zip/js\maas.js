﻿(function() {
    var ODEME_KEY = "maasOdemeList";
    var personelSelect = document.getElementById("maasPersonelSelect");
    var SELECTOR = null;
    function getOdemeList() { return window.StorageHelper.load(ODEME_KEY, []); }
    function personelDoldur() {
        if (!personelSelect) return;
        var list = window.getPersonelList ? window.getPersonelList() : [];
        while (personelSelect.options.length > 1) personelSelect.remove(1);
        list.forEach(function(p) {
            var o = document.createElement("option");
            o.value = p.kod; o.textContent = p.adSoyad + " (" + p.kod + ")";
            personelSelect.appendChild(o);
        });
    }
    function MaasHesapla() {
        if (!SELECTOR) return;
        var p = window.findPersonelByKod(SELECTOR);
        if (!p) return;
        var donem = document.getElementById("maasDonemSelect") ? document.getElementById("maasDonemSelect").value : new Date().toLocaleString("tr-TR", { month: "long", year: "numeric" });
        var logList = window.StorageHelper.load("logList", []);
        var girisler = logList.filter(function(e) { return e.personelKod === p.kod && e.tip === "Giris"; }).length;
        var avans = window.AvansModule ? window.AvansModule.getBekleyen(p.kod) : [];
        var toplamAvans = avans.reduce(function(s, a) { return s + a.miktar; }, 0);
        var maas = parseFloat(p.maas || 0);
        var sonuc = maas + toplamAvans;
        var card = document.getElementById("maasSonucCard");
        var div = document.getElementById("maasSonuc");
        if (card && div) {
            card.style.display = "block";
            div.innerHTML = "<p><strong>Personel:</strong> " + p.adSoyad + "</p><p><strong>Donem:</strong> " + donem + "</p><p><strong>Calisilan Gun:</strong> " + girisler + "</p><p><strong>Avans:</strong> " + toplamAvans.toFixed(2) + " TL</p><p style='font-size:1.3rem;color:#198754;'><strong>Odenecek:</strong> " + sonuc.toFixed(2) + " TL</p>";
        }
        var btn = document.getElementById("btnOdemeYap");
        if (btn) { btn.style.display = "inline-block"; btn.onclick = function() { MaasOdemeYap(p, donem, girisler, toplamAvans, sonuc); }; }
    }
    function MaasOdemeYap(p, donem, gun, avans, net) {
        var list = getOdemeList();
        var existing = list.find(function(o) { return o.personelKod === p.kod && o.donem === donem; });
        if (existing) { alert("Bu donem icin odeiis yapilmis!"); return; }
        list.push({ id: Date.now(), personelKod: p.kod, personelAd: p.adSoyad, donem: donem, calisilanGun: gun, avans: avans, netOdenecek: net, odemeTarih: new Date().toLocaleDateString("tr-TR"), odemeSaat: new Date().toLocaleTimeString("tr-TR") });
        window.StorageHelper.save(ODEME_KEY, list);
        alert("Odeme kaydedildi!");
        if (window.AvansModule) {
            window.AvansModule.getAll().filter(function(a) { return a.personelKod === p.kod && !a.odendi; }).forEach(function(a) { window.AvansModule.odendi(a.id); });
        }
    }
    window.maasTabAcildi = function() { personelDoldur(); };
    window.getOdemeList = getOdemeList;
    window.maasOdemeYap = MaasOdemeYap;
    if (personelSelect) {
        personelSelect.addEventListener("change", function() { SELECTOR = personelSelect.value; if (SELECTOR) MaasHesapla(); });
    }
    var btn = document.getElementById("btnMaasHesapla");
    if (btn) btn.addEventListener("click", MaasHesapla);
})();
