// firebase-config.js - Firebase Konfigurasyonu
window.firebaseConfig = {
    apiKey: "AIzaSyAqjiKdSFxrF3zTQrmsmtbew_2Pvp05scQ",
    authDomain: "ofis-x.firebaseapp.com",
    databaseURL: "https://ofis-x-default-rtdb.firebaseio.com",
    projectId: "ofis-x",
    storageBucket: "ofis-x.firebasestorage.app",
    messagingSenderId: "268718814171",
    appId: "1:268718814171:web:b740981d62f038742f2dfe"
};

window.FIREBASE_KEY = "ofis-x-db";
