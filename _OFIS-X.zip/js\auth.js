﻿window.Auth = (function() {
    var SIFRE_KEY = "ofisXAdminSifre";
    var SIFRE_DEFAULT = "1234";
    function sifreGet() { return localStorage.getItem(SIFRE_KEY) || SIFRE_DEFAULT; }
    function sifreKontrol(input) { return input === sifreGet(); }
    function sifreDegistirYeni() {
        var yeni = prompt("Yeni sifre:");
        if (!yeni || yeni.length < 2) { alert("Gecersiz sifre!"); return; }
        localStorage.setItem(SIFRE_KEY, yeni);
        alert("Sifre degistildi: " + yeni);
    }
    function sifreIste(callback) {
        var girilen = prompt("Sifre girin:");
        if (sifreKontrol(girilen)) callback();
        else alert("Yanlis sifre!");
    }
    return { sifreDegistir: sifreDegistirYeni, sifreIste: sifreIste, sifreKontrol: sifreKontrol };
})();
