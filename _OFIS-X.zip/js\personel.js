﻿(function() {
    var KEY = "personelList";
    function getAll() { return window.StorageHelper.load(KEY, []); }
    function getByKod(kod) { return getAll().find(function(p) { return p.kod === kod; }); }
    function ekle(kod, ad, dep, maas, tel) {
        var list = getAll();
        if (getByKod(kod)) { alert("Bu kod zaten var!"); return false; }
        list.push({ id: Date.now(), kod: kod, adSoyad: ad, departman: dep, aktif: true, maas: maas, tel: tel });
        window.StorageHelper.save(KEY, list);
        renderPersonelTable();
        return true;
    }
    function sil(id) {
        if (!confirm("Silinsin mi?")) return;
        var list = getAll().filter(function(p) { return p.id !== id; });
        window.StorageHelper.save(KEY, list);
        renderPersonelTable();
    }
    function toggle(id) {
        var list = getAll();
        var p = list.find(function(p) { return p.id === id; });
        if (p) { p.aktif = !p.aktif; window.StorageHelper.save(KEY, list); renderPersonelTable(); }
    }
    function renderPersonelTable() {
        var tbody = document.querySelector("#personelTable tbody");
        if (!tbody) return;
        var list = getAll();
        tbody.innerHTML = "";
        if (!list.length) { tbody.innerHTML = "<tr><td colspan='8'>Henuz personel yok</td></tr>"; return; }
        list.forEach(function(p) {
            var tr = document.createElement("tr");
            tr.innerHTML = "<td>" + p.kod + "</td><td>" + p.adSoyad + "</td><td>" + (p.departman||"-") + "</td>" +
                "<td style='color:" + (p.aktif?"green":"red") + ";'>" + (p.aktif?"Aktif","Pasif") + "</td>" +
                "<td>" + p.maas + "</td><td>" + (p.tel||"-") + "</td><td>-</td>" +
                "<td><button class='btn btn-sm btn-danger' onclick='window.PersonelModule.sil(" + p.id + ")'>Sil</button> " +
                "<button class='btn btn-sm' onclick='window.PersonelModule.toggle(" + p.id + ")'>" + (p.aktif?"Pasif","Aktif") + "</button></td>";
            tbody.appendChild(tr);
        });
    }
    function yenPersonel() {
        var kod = prompt("Personel kodu:");
        if (!kod) return;
        var ad = prompt("Ad soyad:");
        if (!ad) return;
        var dep = prompt("Departman:") || "-";
        var maas = prompt("Aylik maas (TL):") || "0";
        var tel = prompt("Telefon:") || "-";
        ekle(kod, ad, dep, maas, tel);
    }
    window.PersonelModule = { getAll: getAll, getByKod: getByKod, ekle: ekle, sil: sil, toggle: toggle, renderTable: renderPersonelTable };
    window.getPersonelList = getAll;
    window.findPersonelByKod = getByKod;
    window.refreshPersonelSelectleri = function() { renderPersonelTable(); };
    var btn = document.getElementById("btnYeniPersonel");
    if (btn) btn.addEventListener("click", yenPersonel);
    window.addEventListener("load", renderPersonelTable);
})();
